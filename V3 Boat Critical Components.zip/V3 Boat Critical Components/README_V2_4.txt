V2.4 SOURCE-AUDITED, LIGHTWEIGHT MICROPLASTIC BOAT (05 Nov 2026)

Use boat_components_v2_4_payload_configs.tex as the MAIN editable source; it embeds the BibTeX bibliography in filecontents*. The standalone .bib and two CSVs are convenience exports.
Compile with pdflatex, biber, pdflatex, pdflatex.

Important: RM 1843.21 for 1 kg case is a conditional PARTIAL cost, not a finished boat price. Shopee variant-specific ESC and RC bundle prices are not confirmed and several fittings remain unpriced. No thrust, payload capacity, two-hour runtime or map validity has been experimentally demonstrated. Only approved registered suppliers (Cytron/GI Electronic) or Shopee Malaysia are used as purchasing links; maker/ArduPilot URLs document specifications, not purchases.
